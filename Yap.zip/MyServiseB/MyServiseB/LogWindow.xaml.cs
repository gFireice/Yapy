﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyServiseB
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        EF3.Entities Entities1 = new EF3.Entities();
       
        public Window2()
        {
            InitializeComponent();
        }


        private void Clik_Enter(object sender, RoutedEventArgs e)
        {
            
            EF3.Worker EnterWorker = new EF3.Worker();

            var authUser = ClassHelper.AppDate.Context.Worker.ToList().
        Where(i => i.Login == TextLogi.Text && i.Password == paswordEnter.Password).FirstOrDefault();
            if (authUser != null)
            {
                Choise choise = new Choise();
                choise.Show();
                Close();
            }      
        }
    }
}
