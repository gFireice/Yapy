﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyServiseB
{
    /// <summary>
    /// Логика взаимодействия для ClientList.xaml
    /// </summary>
    public partial class ClientList : Window
    {
        EF3.OkEntities Entities1 = new EF3.OkEntities();
        List<String> comboList = new List<String>()
            {
                "Стандарт",
                "Имя",
                "Фамилия",
                "Отчество",
                "Роль"
            };
        public ClientList()
        {
            InitializeComponent();
            cmbFilterClient1.SelectedIndex = 0;
            cmbFilterClient1.ItemsSource = comboList;
            
        }
        public void Filter(int a)
        {
            List<EF3.Client> ListClient = ClassHelper.AppDate.Context.Client.ToList();
            switch (a)
            {
                default:
                    break;
                case 1:
                    ListClient = ListClient.Where(i => i.LastName.ToLower().Contains(SearchFilter.Text.ToLower()) ||
                      i.FirstName.ToLower().Contains(SearchFilter.Text.ToLower()) ||
                      i.MidleName.ToLower().Contains(SearchFilter.Text.ToLower()) ||
                      i.Phone.ToLower().Contains(SearchFilter.Text.ToLower()) ||
                      i.Email.ToLower().Contains(SearchFilter.Text.ToLower())).ToList();
                      
            switch (cmbFilterClient1.SelectedIndex)
            {
                case 0:
                    ListClient = ListClient.OrderBy(i => i.ID).ToList();
                    break;
                case 1:
                    ListClient = ListClient.OrderBy(i => i.FirstName).ToList();
                    break;
                case 2:
                    ListClient = ListClient.OrderBy(i => i.LastName).ToList();
                    break;
                case 3:
                    ListClient = ListClient.OrderBy(i => i.MidleName).ToList();
                    break;
                case 4:
                    ListClient = ListClient.OrderBy(i => i.idGender).ToList();
                    break;
            }
                    break;
        }
            ClienTable1.ItemsSource = ListClient;
        }
            private void Clik_AddClient(object sender, RoutedEventArgs e)
        {

        }

        private void Clik_RemoveClient(object sender, RoutedEventArgs e)
        {
            Choise choise = new Choise();
            choise.Show();
            Close();
        }

        private void cmbFilter_SelectionChangedClient(object sender, SelectionChangedEventArgs e)
        {
            Filter(1);
        }

        private void ClienTable1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter(1);
        }

        private void SearchFilter_SelectionChanged(object sender, RoutedEventArgs e)
        {
            Filter(1);
        }

        private void ClienTable1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Delete || e.Key == Key.Return)
            {
                try
                {
                    if (ClienTable1.SelectedItem is EF3.Client)
                    {
                        var Masge = MessageBox.Show("Удалить пользователя?", "Удаление",MessageBoxButton.YesNo,MessageBoxImage.Question);
                        if(Masge==MessageBoxResult.No)
                        {
                            return;
                        }
                        var Cl = ClienTable1.SelectedItem as EF3.Client;

                        //Доработать базу на мяг удаление
                        //ClassHelper.AppDate.Context.SaveChanges();
                        MessageBox.Show("Успешно удалено", "Удаление", MessageBoxButton.OK, MessageBoxImage.Information);
                        Filter(1);
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
