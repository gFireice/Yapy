﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyServiseB
{
    /// <summary>
    /// Логика взаимодействия для ClientList.xaml
    /// </summary>
    public partial class ClientList : Window
    {
        EF3.Entities Entities1 = new EF3.Entities();
        List<String> comboList = new List<String>()
            {
                "Стандарт",
                "Имя",
                "Фамилия",
                "Отчество",
                "Роль"
            };
        public ClientList()
        {
            InitializeComponent();
            cmbFilterClient1.SelectedIndex = 0;
            cmbFilterClient1.ItemsSource = comboList;
            
        }
        public void Filter()
        {
            List<EF3.Client> ListClient = ClassHelper.AppDate.Context.Client.ToList();
            
            switch(cmbFilterClient1.SelectedIndex)
            {
                case 0:
                    ListClient = ListClient.OrderBy(i => i.ID).ToList();
                    break;
                case 1:
                    ListClient = ListClient.OrderBy(i => i.FirstName).ToList();
                    break;
                case 2:
                    ListClient = ListClient.OrderBy(i => i.LastName).ToList();
                    break;
                case 3:
                    ListClient = ListClient.OrderBy(i => i.MidleName).ToList();
                    break;
                case 4:
                    ListClient = ListClient.OrderBy(i => i.idGender).ToList();
                    break;
            }
            ClienTable1.ItemsSource = ListClient;
        }
            private void Clik_AddClient(object sender, RoutedEventArgs e)
        {

        }

        private void Clik_RemoveClient(object sender, RoutedEventArgs e)
        {
            Choise choise = new Choise();
            choise.Show();
            Close();
        }

        private void cmbFilter_SelectionChangedClient(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void ClienTable1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }
    }
}
