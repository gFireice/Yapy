﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyServiseB
{
    /// <summary>
    /// Логика взаимодействия для Choise.xaml
    /// </summary>
    public partial class Choise : Window
    {
        public Choise()
        {
            InitializeComponent();
        }

        private void Clik_Employ(object sender, RoutedEventArgs e)
        {
            Window1 windows1 = new Window1();
            windows1.Show();
            Close();
        }

        private void Clik_Cloase(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Clik_Client(object sender, RoutedEventArgs e)
        {
            ClientList clientList = new ClientList();
            clientList.Show();
            Close();
        }

        private void Clik_Arenda(object sender, RoutedEventArgs e)
        {

        }
    }
}
