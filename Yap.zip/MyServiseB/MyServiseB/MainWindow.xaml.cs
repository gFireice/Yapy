﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyServiseB
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        EF3.Entities Entities1 = new EF3.Entities();
        List<String> comboList = new List<String>()
            {
                "Male",
                "Female"
            };

        public MainWindow()
        {
            InitializeComponent();
            //Cmb_Gender.SelectedIndex = 0;
            //Cmb_Gender.ItemsSource = comboList;
        }

        private void btnClikc_Click(object sender, RoutedEventArgs e)
        {
            
            EF3.Worker newWorker = new EF3.Worker();
            if (txtFname.Text != "" && txtLname.Text != "" && txtLogin.Text != "" && txtPhone.Text != "" && txtPassword.Password != "")
            {
                newWorker.FirstName = txtFname.Text;
                newWorker.LastName = txtLname.Text;
                newWorker.MidleName = txtMname.Text;
                newWorker.Phone = txtPhone.Text;
                newWorker.Email = txtMail.Text;
                newWorker.Login = txtMail.Text;
                newWorker.Password = txtPassword.Password;
            }
        }

        private void Cmb_Gender_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
