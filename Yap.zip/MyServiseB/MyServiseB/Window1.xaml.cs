﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyServiseB
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        EF3.Entities Entities1 = new EF3.Entities();
        List<String> comboList = new List<String>()
            {
                "Стандарт",
                "Имя",
                "Фамилия",
                "Отчество",
                "Роль"
            };
        public Window1()
        {          
            InitializeComponent();
            Filter();
            cmbFilter.ItemsSource = comboList;
            //cmbFilter.SelectedIndex = 0;
        }

        public void Filter()
        {
            List<EF3.Worker> ListWorker = ClassHelper.AppDate.Context.Worker.ToList();
            ClienTable.ItemsSource = ListWorker;

            switch (cmbFilter.SelectedIndex)
            {
                case 0:
                    ListWorker = ListWorker.OrderBy(i => i.ID).ToList();
                    break;

                case 1:
                    ListWorker = ListWorker.OrderBy(i => i.FirstName).ToList();
                    break;

                case 2:
                    ListWorker = ListWorker.OrderBy(i => i.LastName).ToList();
                    break;

                case 3:
                    ListWorker = ListWorker.OrderBy(i => i.MidleName).ToList();
                    break;

                case 4:
                    ListWorker = ListWorker.OrderBy(i => i.idRole).ToList();
                    break;
                default:
                    ListWorker.OrderBy(i => i.ID).ToList();
                    break;
            }
        }

        private void cmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void ClienTable_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                Filter();
            }
        }

        private void Clik_AddEmploy(object sender, RoutedEventArgs e)
        {
           
            MainWindow NewWin = new MainWindow();
            NewWin.Show();
            
        }

        private void Clik_Remove(object sender, RoutedEventArgs e)
        {
            Choise choise = new Choise();
            choise.Show();
        }
    }
    
}
